package IoC;

public class MyClassDao {

    public String insereTexto(String texto){
        System.out.println(texto);
        return "Salvo com sucesso";
    }

}
